This directory contains the screenshot of the output from
render3 (the output from render1 was the same except for the
title of the window).

It also contains the video captured for render2 as this program
contains some animation.

Du Huynh
March 2016

