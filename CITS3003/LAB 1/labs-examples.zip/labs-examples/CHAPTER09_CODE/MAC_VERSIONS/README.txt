example1 - a box containing a number of particles bouncing inside the box.
	Clicking the middle mouse button inside the window should bring
	up a menu. The number of particles, speed of the particles, etc.,
	hould be controllable by the user via the menu.

example2 - fractal

chap09_6E_example1 - should be similar to example1? it seems that the
	box is out of proportion.

Du Huynh

