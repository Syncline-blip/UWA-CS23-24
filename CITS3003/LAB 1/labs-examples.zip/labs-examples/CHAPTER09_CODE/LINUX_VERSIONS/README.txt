example1 - a box containing a number of particles bouncing inside the box.
	Clicking the middle mouse button inside the window should bring
	up a menu whereby the number of particles, speed of the particles, etc.,
	can be adjusted.

example2 - fractal


Du Huynh
March 2017
