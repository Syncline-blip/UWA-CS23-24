The cpp files in this directory have been modified by
Du Huynh.
School of Computer Science and Software Engineering
The University of Western Australia


